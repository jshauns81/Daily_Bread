namespace Daily_Bread.Services;

/// <summary>
/// Types of toast notifications.
/// </summary>
public enum ToastType
{
    Success,
    Error,
    Warning,
    Info
}

/// <summary>
/// Represents a toast notification message.
/// </summary>
public class ToastMessage
{
    public Guid Id { get; } = Guid.NewGuid();
    public required string Title { get; init; }
    public string? Message { get; init; }
    public ToastType Type { get; init; } = ToastType.Info;
    public int DurationMs { get; init; } = 4000;
    public DateTime CreatedAt { get; } = DateTime.UtcNow;
    public bool IsVisible { get; set; } = true;
    
    /// <summary>
    /// Bootstrap Icon class based on toast type.
    /// </summary>
    public string IconClass => Type switch
    {
        ToastType.Success => "bi-check-lg",
        ToastType.Error => "bi-x-circle",
        ToastType.Warning => "bi-exclamation-triangle",
        ToastType.Info => "bi-info-circle",
        _ => "bi-info-circle"
    };
    
    /// <summary>
    /// CSS class based on toast type.
    /// </summary>
    public string CssClass => Type switch
    {
        ToastType.Success => "toast-success",
        ToastType.Error => "toast-error",
        ToastType.Warning => "toast-warning",
        ToastType.Info => "toast-info",
        _ => "toast-info"
    };
}

/// <summary>
/// Service for managing toast notifications.
/// </summary>
public interface IToastService
{
    /// <summary>
    /// Event fired when toasts change.
    /// </summary>
    event Action? OnChange;
    
    /// <summary>
    /// Gets all active toasts.
    /// </summary>
    IReadOnlyList<ToastMessage> Toasts { get; }
    
    /// <summary>
    /// Shows a success toast.
    /// </summary>
    void ShowSuccess(string title, string? message = null, int durationMs = 4000);
    
    /// <summary>
    /// Shows an error toast.
    /// </summary>
    void ShowError(string title, string? message = null, int durationMs = 6000);
    
    /// <summary>
    /// Shows a warning toast.
    /// </summary>
    void ShowWarning(string title, string? message = null, int durationMs = 5000);
    
    /// <summary>
    /// Shows an info toast.
    /// </summary>
    void ShowInfo(string title, string? message = null, int durationMs = 4000);
    
    /// <summary>
    /// Shows a custom toast.
    /// </summary>
    void Show(ToastMessage toast);
    
    /// <summary>
    /// Removes a specific toast.
    /// </summary>
    void Remove(Guid toastId);
    
    /// <summary>
    /// Clears all toasts.
    /// </summary>
    void Clear();
}

/// <summary>
/// Implementation of toast notification service with proper cancellation support.
/// </summary>
public class ToastService : IToastService, IDisposable
{
    private readonly List<ToastMessage> _toasts = [];
    private readonly Dictionary<Guid, CancellationTokenSource> _removalTokens = new();
    private readonly object _lock = new();
    private bool _disposed;
    
    public event Action? OnChange;
    
    public IReadOnlyList<ToastMessage> Toasts
    {
        get
        {
            lock (_lock)
            {
                return _toasts.ToList().AsReadOnly();
            }
        }
    }
    
    public void ShowSuccess(string title, string? message = null, int durationMs = 4000)
    {
        Show(new ToastMessage
        {
            Title = title,
            Message = message,
            Type = ToastType.Success,
            DurationMs = durationMs
        });
    }
    
    public void ShowError(string title, string? message = null, int durationMs = 6000)
    {
        Show(new ToastMessage
        {
            Title = title,
            Message = message,
            Type = ToastType.Error,
            DurationMs = durationMs
        });
    }
    
    public void ShowWarning(string title, string? message = null, int durationMs = 5000)
    {
        Show(new ToastMessage
        {
            Title = title,
            Message = message,
            Type = ToastType.Warning,
            DurationMs = durationMs
        });
    }
    
    public void ShowInfo(string title, string? message = null, int durationMs = 4000)
    {
        Show(new ToastMessage
        {
            Title = title,
            Message = message,
            Type = ToastType.Info,
            DurationMs = durationMs
        });
    }
    
    public void Show(ToastMessage toast)
    {
        if (_disposed) return;
        
        lock (_lock)
        {
            _toasts.Add(toast);
            
            // Limit to 5 toasts max
            while (_toasts.Count > 5)
            {
                var oldest = _toasts[0];
                CancelAndRemoveToken(oldest.Id);
                _toasts.RemoveAt(0);
            }
        }
        
        OnChange?.Invoke();
        
        // Schedule auto-removal with cancellation support
        if (toast.DurationMs > 0)
        {
            ScheduleRemoval(toast.Id, toast.DurationMs);
        }
    }
    
    public void Remove(Guid toastId)
    {
        lock (_lock)
        {
            CancelAndRemoveToken(toastId);
            
            var toast = _toasts.FirstOrDefault(t => t.Id == toastId);
            if (toast != null)
            {
                toast.IsVisible = false;
                _toasts.Remove(toast);
            }
        }
        
        OnChange?.Invoke();
    }
    
    public void Clear()
    {
        lock (_lock)
        {
            // Cancel all pending removal tasks
            foreach (var cts in _removalTokens.Values)
            {
                cts.Cancel();
                cts.Dispose();
            }
            _removalTokens.Clear();
            _toasts.Clear();
        }
        
        OnChange?.Invoke();
    }
    
    private void ScheduleRemoval(Guid toastId, int delayMs)
    {
        var cts = new CancellationTokenSource();
        
        lock (_lock)
        {
            _removalTokens[toastId] = cts;
        }
        
        _ = RemoveAfterDelayAsync(toastId, delayMs, cts.Token);
    }
    
    private async Task RemoveAfterDelayAsync(Guid toastId, int delayMs, CancellationToken cancellationToken)
    {
        try
        {
            await Task.Delay(delayMs, cancellationToken);
            
            if (!cancellationToken.IsCancellationRequested)
            {
                Remove(toastId);
            }
        }
        catch (TaskCanceledException)
        {
            // Expected when toast is manually dismissed or service is disposed
        }
    }
    
    private void CancelAndRemoveToken(Guid toastId)
    {
        if (_removalTokens.TryGetValue(toastId, out var cts))
        {
            cts.Cancel();
            cts.Dispose();
            _removalTokens.Remove(toastId);
        }
    }
    
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        
        Clear();
    }
}
