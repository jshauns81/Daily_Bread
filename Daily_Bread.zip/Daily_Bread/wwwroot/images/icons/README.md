# Daily Bread PWA Icons
# This directory contains PWA icons in various sizes.
# 
# Required icons:
# - icon-72x72.png
# - icon-96x96.png
# - icon-128x128.png
# - icon-144x144.png
# - icon-152x152.png
# - icon-192x192.png
# - icon-384x384.png
# - icon-512x512.png
#
# To generate these icons from bread-icon.png:
# 1. Use an online tool like https://realfavicongenerator.net/
# 2. Or use ImageMagick:
#    convert bread-icon.png -resize 72x72 icon-72x72.png
#    convert bread-icon.png -resize 96x96 icon-96x96.png
#    etc.
#
# For now, the manifest will fall back to bread-icon.png
